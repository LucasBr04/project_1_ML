# Rapport LaTeX BRFSS

## Fichiers

- `report.tex` : rapport anglais modifiable, avec zones `[Team: ...]` et auteurs à compléter.
- `report.pdf` : version compilée et vérifiée, 2 pages.
- `IEEEtran.cls`, `IEEEtran.bst` : fichiers repris du dossier `latex-example-paper` fourni.
- `literature.bib` : référence au document du projet effectivement consulté. Les références sur la rédaction scientifique de l'exemple ne sont pas recopiées, car elles ne constituent pas des sources scientifiques des expériences.
- `figures/ridge_f1_calibration.png` : figure reconstruite en anglais à partir de `plot/ridge_df.csv`, sans modifier les valeurs.
- `build.sh` : compilation locale avec pdfLaTeX et BibTeX.

Pour Overleaf : importer tous les fichiers de l'archive et définir `report.tex` comme document principal. Le PDF et les sources font partie du même dossier.

## Structure retenue et consignes

Modèle exact : `\documentclass[10pt,conference,compsocconf]{IEEEtran}`. Format IEEE en deux colonnes, sans changement de marges ni réduction globale de police. Organisation préconisée dans le modèle : Abstract, Introduction, Models and Methods, Results, Discussion, Summary. Le preprocessing et le protocole expérimental sont des sous-parties des méthodes.

Le document `project1_description.pdf`, pages 1 et 7, impose 2 pages maximum, sans annexe, et autorise une troisième page uniquement pour les références. Le PDF d'exemple fait 3 pages parce qu'il explique la rédaction ; ce n'est pas la limite à appliquer au rapport du projet. La version produite fait 2 pages, références incluses. Vérifier de nouveau la longueur après les ajouts des coéquipiers.

Le rapport conserve une figure (F1 de calibration selon lambda) et un tableau (évaluation indépendante), avec des légendes, labels et renvois. Les noms des auteurs, de l'équipe et les résultats des autres modèles restent à compléter. Aucun résultat, score de compétition ou intervalle de confiance n'a été inventé. L'absence d'évaluation multi-split est mentionnée au lieu de produire une moyenne et une variance artificielles.

## Sources expérimentales et vérification

Sources locales : `/Users/williamweber/Desktop/EPFL/MA1/project_1_ML/Least_Squares_Ridge_BRFSS.ipynb`, `preprocessing.py`, `implementations.py`, `helpers.py`, en-tête de `data/x_train.csv`, `plot/comparison.csv` et `plot/ridge_df.csv`. Les métriques du tableau ont été vérifiées à partir des matrices de confusion. Le lambda et le seuil Ridge correspondent au maximum du F1 calibré exporté.

Le rapport utilise les résultats enregistrés, sans relancer l'entraînement. Le code source et les données du projet d'origine ne sont pas modifiés.

## Points à résoudre avant soumission

- Remplacer tous les champs d'auteur, d'équipe, `TBC` et `[Team: ...]`.
- Compléter les méthodes et résultats des coéquipiers, puis mettre à jour abstract, discussion et conclusion.
- La cellule Ridge référence `compute_loss` sans définition ni import ; la fonction `mse` disponible calcule la demi-MSE. Corriger la référence et vérifier une exécution avec un noyau neuf.
- L'assertion de soumission teste `best_threshold`, tandis que la variable sélectionnée s'appelle `best_ridge_threshold`.
- Les règles du projet autorisent les bibliothèques standard, NumPy et les bibliothèques de visualisation pour les graphiques. Le notebook utilise Pandas et `scipy.linalg.qr` : ces dépendances doivent être remplacées pour respecter ces règles, puis les résultats doivent être vérifiés de nouveau. Ne pas décrire une nouvelle procédure comme déjà exécutée avant cette vérification.
- Les références au code non reproductible dans la discussion pourront être retirées lorsque ces points auront été effectivement résolus et les résultats confirmés.
- Aucun effet propre du preprocessing ni aucune significativité n'a été démontré : ne pas ajouter de conclusions d'ablation ou statistiques sans expériences supplémentaires.

## Compilation

Depuis ce dossier :

```sh
sh build.sh
```

La compilation nécessite une installation LaTeX avec pdfLaTeX, BibTeX, amsmath, graphicx, booktabs et hyperref. Le projet contient sa classe IEEE, sa bibliographie et sa figure ; il n'est pas un fichier TeX autonome.

## Répartition confirmée des six méthodes

- William : Least Squares et Ridge Regression.
- Coéquipier 1 : régression linéaire avec GD et avec SGD (batch size 1).
- Coéquipier 2 : Logistic Regression et Regularized Logistic Regression.

Les quatre méthodes des coéquipiers ont chacune une ligne réservée dans le tableau. Leurs résultats restent à compléter. GD/SGD font partie des six méthodes demandées par le projet et ne sont pas des ajouts facultatifs.
